<?php

$hn = 'localhost:3306';
$db = 'parkinglot';
$un = 'root';
$pw = '';

?>