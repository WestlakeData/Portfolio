<!DOCTYPE html>
<?php
	$page_roles = array('admin');
	require_once 'user.php';
	require_once 'checksession.php';
?>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="IS 6465 Final Project" />
        <meta name="author" content="Group5" />
        <title>Edit Violation</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light">Navigation</div>
                <div class="list-group list-group-flush">
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-home.php">Home</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-driver.php">Driver Management</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-vehicle.php">Vehicle Management</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-permit.php">Permit Management</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-viol.php">Violation Management</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-parking.php">Parking Lot Management</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-reports.php">Reports</a>  
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <button class="btn btn-primary" id="sidebarToggle">Toggle Navigation Menu</button>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li class="nav-item active"><a class="nav-link" href="logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <!-- Page content-->
                <div class="container-fluid">
					<img src='../assets/universityofutah-logo-1'>
                    <h1 class="mt-4">Parking System Management</h1>
					<form method='post' action='admin-update-viol.php'>
					<table align='center'>
							
					<?php
						require_once 'dbinfo.php';
												
						$conn = new mysqli($hn, $un, $pw, $db);
						if($conn->connect_error) die($conn->connect_error);
						
						if(isset($_GET['id'])){
							$violationID = $_GET['id'];	//GET violation_id

							// Query
							$query = "SELECT * FROM violation AS vi JOIN violation_type AS vt ON 
								vi.violation_type_id = vt.violation_type_id JOIN user AS u ON 
								vi.employee_id = u.employee_id JOIN vehicle AS v ON 
								vi.vehicle_id = v.vehicle_id
								WHERE violation_id = $violationID ";
							$result = $conn->query($query);
							if(!$result) die($conn->error);
							
							$queryViolList = "SELECT violation_name, violation_type_id FROM violation_type";
							$resultViolName = $conn->query($queryViolList);
							if(!$resultViolName) die($conn->error);
							
							$queryEmpList = "SELECT user_id, employee_id FROM user WHERE employee_id > 0";
							$resultEmpName = $conn->query($queryEmpList);
							if(!$resultEmpName) die($conn->error);
							
							$queryLP = "SELECT vehicle_id, license_plate FROM vehicle";
							$resultLP = $conn->query($queryLP);
							if(!$resultLP) die($conn->error);
							
							$row = $result->fetch_array(MYSQLI_ASSOC);
							$numTypes = $resultViolName->num_rows;
							$numEmp = $resultEmpName->num_rows;
							$numLP = $resultLP->num_rows;
							
							echo <<<_END
							<input type ='hidden' name='update' value='yes'>
							<input type ='hidden' name='violation_id' value='$violationID'>
							<table align='center'>
								<tr>
									<td align='right'>License Plate:</td>
									<td>&emsp;<select name='license_plate' id='license_plate'>
							_END;
								for($j=0; $j<$numLP; $j++){
									$lp = $resultLP->fetch_array(MYSQLI_ASSOC);
									echo "<option value='$lp[vehicle_id]'>$lp[license_plate]</option>";
								}
							echo <<<_END
									</select></td>
								</tr>
								<tr>
									<td align='right'>Violation Type:</td>
									<td>&emsp;<select name='viol_type' id='viol_type'>
							_END;
								for($j=0; $j<$numTypes; $j++){
									$violType = $resultViolName->fetch_array(MYSQLI_ASSOC);
									echo "<option value='$violType[violation_type_id]'>$violType[violation_name]</option>";
								}
							echo <<<_END
									</select></td>
								</tr>
								<tr>
									<td align='right'>Date Issued:</td>
									<td>&emsp;<input type='text' name='issue_date' value='$row[violation_date]'></td>
								</tr>
								<tr>
									<td align='right'>Issued By:</td>
									<td>&emsp;<select name='empID' id='empID'>
							_END;
								for($j=0; $j<$numEmp; $j++){
									$empName = $resultEmpName->fetch_array(MYSQLI_ASSOC);
									echo "<option value='$empName[employee_id]'>$empName[user_id]</option>";
								}
							echo <<<_END
									</select></td>
								</tr>
								<tr>
									<td></td>
									<td><input type='submit' value='Edit Violation Info'></td>
								</tr>
							</table>
						</form>
						_END;
					}else{
						$violationID = '';
						
						// Queries
							$query1 = "SELECT violation_name, violation_type_id FROM violation_type";
							$result1 = $conn->query($query1);
							if(!$result1) die($conn->error);
							
							$query2 = "SELECT user_id, employee_id FROM user WHERE employee_id > 0";
							$result2 = $conn->query($query2);
							if(!$result2) die($conn->error);
							
							$query3 = "SELECT vehicle_id, license_plate FROM vehicle";
							$result3 = $conn->query($query3);
							if(!$result3) die($conn->error);
							
							$numTypes = $result1->num_rows;
							$numEmp = $result2->num_rows;
							$numLP = $result3->num_rows;
							
							echo <<<_END
								<input type ='hidden' name='new_viol' value='yes'>
								<table align='center'>
								<tr>
									<td align='right'>License Plate:</td>
									<td>&emsp;<select name='license_plate' id='license_plate'>
							_END;
								for($j=0; $j<$numLP; $j++){
									$lp = $result3->fetch_array(MYSQLI_ASSOC);
									echo "<option value='$lp[vehicle_id]'>$lp[license_plate]</option>";
								}
							echo <<<_END
									</select></td>
								</tr>
								<tr>
									<td align='right'>Violation Type:</td>
									<td>&emsp;<select name='viol_type' id='viol_type'>
							_END;
								for($j=0; $j<$numTypes; $j++){
									$violType = $result1->fetch_array(MYSQLI_ASSOC);
									echo "<option value='$violType[violation_type_id]'>$violType[violation_name]</option>";
								}
							echo <<<_END
									</select></td>
								</tr>
								<tr>
									<td align='right'>Issued By:</td>
									<td>&emsp;<select name='empID' id='empID'>
							_END;
								for($j=0; $j<$numEmp; $j++){
									$empName = $result2->fetch_array(MYSQLI_ASSOC);
									echo "<option value='$empName[employee_id]'>$empName[user_id]</option>";
								}
							echo <<<_END
									</select></td>
								</tr>
								<tr>
									<td align='right'>Issue Date:</td>
									<td>&emsp;<input type='text' name='issue_date'></td>
								</tr>
								<tr>
									<td></td>
									<td><input type='submit' value='Add New Violation'></td>
								</tr>
							</table>
						</form>
						_END;
					}

					?>
					</table>
					</form>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="../js/scripts.js"></script>
    </body>
</html>
