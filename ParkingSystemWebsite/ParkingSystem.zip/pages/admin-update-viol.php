<?php
$page_roles = array('admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

if(isset($_POST['update'])) {
	if(isset($_POST['violation_id']) &&
		isset($_POST['license_plate']) &&
		isset($_POST['viol_type']) &&
		isset($_POST['issue_date']) &&
		isset($_POST['empID']) ) {
			$violType=get_post($conn,'viol_type');
			$vehicleID=get_post($conn,'license_plate');
			$issueDate=get_post($conn,'issue_date');
			$violationID=get_post($conn, 'violation_id');
			$empID=get_post($conn,'empID');
			
			// UPDATE Query
			$query = "UPDATE violation SET vehicle_id = '$vehicleID', violation_type_id = '$violType', violation_date = '$issueDate', employee_id = '$empID' WHERE violation_id = '$violationID' ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);
			
							
	}
	
	$conn->close();

}elseif(isset($_POST['new_viol'])){
	if(isset($_POST['license_plate']) &&
		isset($_POST['viol_type']) &&
		isset($_POST['issue_date']) &&
		isset($_POST['empID'])) {
			$violType=get_post($conn, 'viol_type');
			$vehicleID=get_post($conn, 'license_plate');
			$issueDate=get_post($conn, 'issue_date');
			$empID=get_post($conn, 'empID');
			
			// UPDATE Query
			$query = "INSERT INTO violation SET violation_type_id = '$violType', employee_id = '$empID', violation_date = '$issue_date', vehicle_id = '$vehicleID' ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);	
		}
	$conn->close();
	
}else{
	echo 'Error Updating Violation Info<br>';
	echo '<a href="admin-viol.php">Return to Violation Info</a>';
}

function get_post($conn, $var) {
		return $conn->real_escape_string($_POST[$var]);
}
header('Location: admin-viol.php')
?>