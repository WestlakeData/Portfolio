<?php
$page_roles = array('admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

$permitID = $_GET['id'];

if(isset($permitID)) {
	// DELETE Query
		$query = "DELETE FROM permit WHERE permit_id = '$permitID' ";
		$result = $conn->query($query); 
		if(!$result) die($conn->error);
	
	$conn->close();

}else{
	echo 'Error Deleting Permit<br>';
	echo '<a href="admin-permit.php">Return to Permit List Info</a>';
}

header("Location: admin-permit.php");
?>