<?php
$page_roles = array('user', 'admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

if(isset($_POST['payment'])) {
	if(isset($_POST['violationID'])) {
			$violationID=get_post($conn, 'violationID');
			
			// DELETE Query
			$query = "DELETE FROM violation WHERE violation_id = $violationID ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);	
	}
	
	$conn->close();

}else{
	echo 'Error Completing Payment<br>';
	echo '<a href="user-violation-info.php">Return to Violation Info</a>';
}

function get_post($conn, $var) {
		return $conn->real_escape_string($_POST[$var]);
}
header("Location: viol-thankyou.php");
?>