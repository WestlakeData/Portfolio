<?php
$page_roles = array('admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

if(isset($_POST['update'])) {
	if(isset($_POST['licenseNum']) &&
		isset($_POST['vehicle_id']) &&
		isset($_POST['year']) &&
		isset($_POST['model']) &&
		isset($_POST['make']) &&
		isset($_POST['color'])) {
			$lp=get_post($conn, 'licenseNum');
			$vehicleYear=get_post($conn, 'year');
			$vehicleModel=get_post($conn, 'model');
			$vehicleMake=get_post($conn, 'make');
			$vehicleColor=get_post($conn, 'color');
			$vehicleID=get_post($conn, 'vehicle_id');
			
			// UPDATE Query
			$query = "UPDATE vehicle SET license_plate = '$lp', vehicle_year = '$vehicleYear', vehicle_model = '$vehicleModel', vehicle_color = '$vehicleColor' WHERE vehicle_id = '$vehicleID' ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);
			
							
	}
	
	$conn->close();

}elseif(isset($_POST['new_vehicle'])){
	if(isset($_POST['licenseNum']) &&
		isset($_POST['driver_id']) &&
		isset($_POST['year']) &&
		isset($_POST['model']) &&
		isset($_POST['make']) &&
		isset($_POST['color'])) {
			$lp=get_post($conn, 'licenseNum');
			$driverID=get_post($conn, 'driver_id');
			$vehicleYear=get_post($conn, 'year');
			$vehicleMake=get_post($conn, 'make');
			$vehicleModel=get_post($conn, 'model');
			$vehicleColor=get_post($conn, 'color');
			
			
			// UPDATE Query
			$query = "INSERT INTO vehicle SET driver_id = '$driverID', license_plate= '$lp', vehicle_year = '$vehicleYear', vehicle_make = '$vehicleMake', vehicle_model = '$vehicleModel', vehicle_color = '$vehicleColor' ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);	
		}
}else{
	echo 'Error Updating Driver Info<br>';
	echo '<a href="user-info.php">Return to Driver Info</a>';
}

function get_post($conn, $var) {
		return $conn->real_escape_string($_POST[$var]);
}
header("Location: admin-vehicle.php");
?>