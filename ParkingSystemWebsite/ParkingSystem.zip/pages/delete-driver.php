<?php
$page_roles = array('admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

$driverID = $_GET['id'];

if(isset($driverID)) {
	// DELETE Query
		$query = "DELETE FROM driver WHERE driver_id = '$driverID' ";
		$result = $conn->query($query); 
		if(!$result) die($conn->error);
	
	$conn->close();

}else{
	echo 'Error Completing Payment<br>';
	echo '<a href="admin-driver.php">Return to Driver List Info</a>';
}

header("Location: admin-driver.php");
?>