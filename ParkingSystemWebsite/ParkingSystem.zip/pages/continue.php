<?php
require_once 'user.php';
$page_roles = array('admin', 'user');

session_start();

if($_SESSION['user']){
	
	$user = $_SESSION['user'];
	$username = $user->username;
	$driverID = $user->driver_id;
	$user_roles = $user->getRoles();
	
	$found=0;
	foreach ($user_roles as $urole){
		foreach ($page_roles as $prole){{
			if($urole==$prole){
				$found = 1;
			}
		}
	}}
	
	if(!$found){
		header('Location: unauthorized.php');
	}elseif($user_roles=='admin'){
		header('Location: admin-home.php');
	}else{
		header('Location: home.php');
	}
}

?>