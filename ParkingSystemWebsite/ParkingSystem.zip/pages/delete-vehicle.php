<?php
$page_roles = array('admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

$vehicleID = $_GET['id'];

if(isset($driverID)) {
	// DELETE Query
		$query = "DELETE FROM vehicle WHERE vehicle_id = '$vehicleID' ";
		$result = $conn->query($query); 
		if(!$result) die($conn->error);
	
	$conn->close();

}else{
	echo 'Error Completing Payment<br>';
	echo '<a href="admin-vehicle.php">Return to Vehicle List Info</a>';
}

header("Location: admin-vehicle.php");
?>