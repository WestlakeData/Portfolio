<?php
$page_roles = array('user', 'admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

if(isset($_POST['update'])) {
	if(isset($_POST['fName']) &&
		isset($_POST['mName']) &&
		isset($_POST['lName']) &&
		isset($_POST['email']) &&
		isset($_POST['phone']) &&
		isset($_POST['address']) &&
		isset($_POST['zip']) &&
		isset($_POST['driver_id'])) {
			$fname=get_post($conn, 'fName');
			$mname=get_post($conn, 'mName');
			$lname=get_post($conn, 'lName');
			$email=get_post($conn, 'email');
			$phone=get_post($conn, 'phone');
			$address=get_post($conn, 'address');
			$zip=get_post($conn, 'zip');
			$driverID = $_POST['driver_id'];
			
			// UPDATE Query
			$query = "UPDATE driver SET first_name = '$fname', middle_name = '$mname', last_name = '$lname', driver_email = '$email', driver_phone_number = '$phone', driver_address = '$address', driver_zip = '$zip' WHERE driver_id = '$driverID' ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);
			
							
	}
	
	$conn->close();

}else{
	echo 'Error Updating Driver Info<br>';
	echo '<a href="user-info.php">Return to Driver Info</a>';
}

function get_post($conn, $var) {
		return $conn->real_escape_string($_POST[$var]);
}
header("Location: user-info.php");
?>