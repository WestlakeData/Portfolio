<?php

require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

// Query
$query = "SELECT user_id, password FROM user";
$result = $conn->query($query); 
if(!$result) die($conn->error);


$rows = $rows = $result->num_rows;

for($j=0; $j<$rows; $j++){
	$row = $result->fetch_array(MYSQLI_ASSOC);
	echo 'user_id: '.$row['user_id'].'<br>';
	echo 'password: '.$row['password'].'<br>';
	$username = $row['user_id'];
	$password = $row['password'];
	$token = password_hash($password,PASSWORD_DEFAULT);

	add_user($conn, $username, $token);
	echo 'User Updated<br>';
	echo '<br>';
	
}

function add_user($conn, $username, $token){
	//code to add user here
	$query = "UPDATE user SET hash = '$token' WHERE user_id = '$username'";
	$result = $conn->query($query);
	if(!$result) die($conn->error);
}

?>