<?php
$page_roles = array('admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

if(isset($_POST['update'])) {
	if(isset($_POST['permit_type']) &&
		isset($_POST['purchase_date']) &&
		isset($_POST['expiration_date']) &&
		isset($_POST['permit_id'])) {
			$permitType=get_post($conn, 'permit_type');
			$purchaseDate=get_post($conn, 'purchase_date');
			$expirationDate=get_post($conn, 'expiration_date');
			$permitID=get_post($conn, 'permit_id');
			
			// UPDATE Query
			$query = "UPDATE permit SET permit_type = '$permitType', purchase_date = '$purchaseDate', expiration_date = '$expirationDate' WHERE permit_id = '$permitID' ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);
			
							
	}
	
	$conn->close();

}elseif(isset($_POST['new_permit'])){
	if(isset($_POST['permit_type']) &&
		isset($_POST['purchase_date']) &&
		isset($_POST['expiration_date'])) {
			$permitType=get_post($conn, 'permit_type');
			$purchaseDate=get_post($conn, 'purchase_date');
			$expirationDate=get_post($conn, 'expiration_date');
			
			
			// UPDATE Query
			$query = "INSERT INTO permit SET permit_type = '$permitType', purchaseDate= '$purchaseDate', expiration_date = '$expirationDate' ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);	
		}
}else{
	echo 'Error Updating Permit Info<br>';
	echo '<a href="admin-permit.php">Return to Permit Info</a>';
}

function get_post($conn, $var) {
		return $conn->real_escape_string($_POST[$var]);
}
header("Location: admin-permit.php");
?>