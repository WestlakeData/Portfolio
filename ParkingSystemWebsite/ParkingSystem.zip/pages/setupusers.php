<?php

require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

//Bill Smith
$username = 'bsmith';
$password = 'mysecret';
$token = password_hash($password,PASSWORD_DEFAULT); 

add_user($conn, $username, $password, $token);

//Pauline Jones
$username = 'pjones';
$password = 'acrobat';
$token = password_hash($password,PASSWORD_DEFAULT);

add_user($conn, $username, $password, $token);

//Jaqwaun Collins
$username = 'jcollins';
$password = 'password123';
$token = password_hash($password,PASSWORD_DEFAULT);

add_user($conn, $username, $password, $token);

//Chris Porter
$username = 'cporter';
$password = 'mypassword';
$token = password_hash($password,PASSWORD_DEFAULT);

add_user($conn, $username, $password, $token);

function add_user($conn, $username, $password, $token){
	//code to add user here
	$query = "UPDATE driver SET pw = '$password', hash = '$token' WHERE username = '$username'";
	$result = $conn->query($query);
	if(!$result) die($conn->error);
}



?>


