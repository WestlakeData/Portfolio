<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="IS 6465 Final Project" />
        <meta name="author" content="Group5" />
        <title>Purchase a Parking Permit</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light">Navigation</div>
                <div class="list-group list-group-flush">
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="home.php">Home</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="user-info.php">Driver Profile</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="user-vehicle-info.php">Vehicle Information</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="user-permit-info.php">Permits</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="user-violation-info.php">Violations</a>
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <button class="btn btn-primary" id="sidebarToggle">Toggle Navigation Menu</button>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li class="nav-item active"><a class="nav-link" href="logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <!-- Page content-->
                <div class="container-fluid">
					<img src='../assets/universityofutah-logo-1'>
                    <h1 class="mt-4">Parking System Management</h1>
                    <!-- Place Page Content HERE -->
					<p>Choose your Parking Permit:</p>

					<form method='post' action='new-permit.php'>
					<input type='hidden' name='purchase' value='yes'>
					  <select name='permitExp' size='1'>
						<option selected= 'selected' value='2022-12-31'>Dec 2022</option>
						<option value='2023-04-30'>Apr 2023</option>
						<option value='2023-08-31'>Aug 2023</option>
					  </select>
					  <br>
					  <input type="radio" id="U" name="permitType" value="U">
					  <label for="U">U Student Parking Permit</label><br>				  
					  <input type="radio" id="HU" name="permitType" value="HU">
					  <label for="HU">HU Student Parking Permit</label><br>			  
					  <input type="radio" id="A" name="permitType" value="A">
					  <label for="A">A Faculty Parking Permit</label><br> 
					  <input type="radio" id="CU" name="permitType" value="CU">
					  <label for="CU">CU Parking Permit</label><br>
					  <input type="radio" id="HCU" name="permitType" value="HCU">
					  <label for="HCU">HCU Parking Permit</label><br>
					  <input type="radio" id="SHU" name="permitType" value="SHU">
					  <label for="SHU">SHU Student Parking Permit</label><br>
					  <input type="radio" id="RP" name="permitType" value="RP">
					  <label for="RP">Research Park Parking Permit</label><br>
					  <input type="radio" id="CA" name="permitType" value="CA">
					  <label for="CA">CA Parking Permit</label><br>
					  <input type="radio" id="M" name="permitType" value="M">
					  <label for="M">Mortorcycle Parking Permit</label><br>
					  <input type='reset'>&emsp;<input type='submit' value='Purchase Permit'>
					</form>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="../js/scripts.js"></script>
    </body>
</html>
