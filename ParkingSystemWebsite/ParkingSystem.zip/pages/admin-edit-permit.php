<!DOCTYPE html>
<?php
	$page_roles = array('admin');
	require_once 'user.php';
	require_once 'checksession.php';
?>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="IS 6465 Final Project" />
        <meta name="author" content="Group5" />
        <title>Edit Permit</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light">Navigation</div>
                <div class="list-group list-group-flush">
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-home.php">Home</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-driver.php">Driver Management</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-vehicle.php">Vehicle Management</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-permit.php">Permit Management</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-viol.php">Violation Management</a>
					<a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-parking.php">Parking Lot Management</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="admin-reports.php">Reports</a>  
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <button class="btn btn-primary" id="sidebarToggle">Toggle Navigation Menu</button>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li class="nav-item active"><a class="nav-link" href="logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <!-- Page content-->
                <div class="container-fluid">
					<img src='../assets/universityofutah-logo-1'>
                    <h1 class="mt-4">Parking System Management</h1>
					<form method='post' action='admin-update-permit.php'>
					<table align='center'>
							
					<?php
						require_once 'dbinfo.php';
												
						$conn = new mysqli($hn, $un, $pw, $db);
						if($conn->connect_error) die($conn->connect_error);
						
						if(isset($_GET['id'])){
							$permitID = $_GET['id'];	//GET permit_id

							// Query
							$query = "SELECT * FROM permit JOIN driver ON permit.driver_id=driver.driver_id WHERE permit_id = $permitID ";
							$result = $conn->query($query);
							if(!$result) die($conn->error);
							
							$queryPermitList = "SELECT permit_type FROM permit";
							$resultPermitType = $conn->query($queryPermitList);
							if(!$resultPermitType) die($conn->error);
							
							$row = $result->fetch_array(MYSQLI_ASSOC);
							$numTypes = $resultPermitType->num_rows;
							
							echo <<<_END
							<input type ='hidden' name='update' value='yes'>
							<input type = 'hidden' name='permit_id' value='$row[permit_id]'>
							<table align='center'>
								<tr>
									<td align='right'>Driver:</td>
									<td>&emsp;$row[first_name] $row[last_name]</td>
								</tr>
								<tr>
									<td align='right'>Permit Type:</td>
									<td>&emsp;<select name='permit_type' id='permit_type'>
							_END;
								for($j=0; $j<$numTypes; $j++){
									$permitType = $resultPermitType->fetch_array(MYSQLI_ASSOC);
									echo "<option value='$permitType[permit_type]'>$permitType[permit_type]</option>";
								}
							echo <<<_END
									</select></td>
								</tr>
								<tr>
									<td align='right'>Purchase Date:</td>
									<td>&emsp;<input type='text' name='purchase_date' value='$row[purchase_date]'></td>
								</tr>
								<tr>
									<td align='right'>Expiration Date:</td>
									<td>&emsp;<input type='text' name='expiration_date' value='$row[expiration_date]'></td>
								</tr>
								<tr>
									<td></td>
									<td><input type='submit' value='Edit Permit Info'></td>
								</tr>
							</table>
						</form>
						_END;
					}else{
						$permitID = '';
						
						// Query
							$query = "SELECT driver_id, CONCAT(first_name,' ',last_name) AS driverName FROM driver";
							$result = $conn->query($query); 
							if(!$result) die($conn->error);
							
							$queryPermitList = "SELECT permit_type FROM permit";
							$resultPermitType = $conn->query($queryPermitList);
							if(!$resultPermitType) die($conn->error);
							
							// Get number of rows in result
							$numRows = $result->num_rows;
							$numTypes = $resultPermitType->num_rows;
							echo <<<_END
								<input type ='hidden' name='new_permit' value='yes'>
								<table align='center'>
								<td>Select Driver:</td>
								<td>&emsp;<select name='driver_id' id='driver_id'>
							_END;
								for($j=0; $j<$numRows; $j++){
									$row = $result->fetch_array(MYSQLI_ASSOC);
									echo "<option value='$row[driver_id]'>$row[driverName]</option>";
								}
							echo <<<_END
								</select></td>
								<tr>
									<td align='right'>License Plate:</td>
									<td>&emsp;<input type='text' name= 'license_plate'></td>
								</tr>
								<tr>
									<td align='right'>Permit Type:</td>
									<td>&emsp;<select name='permit_type' id='permit_type'>
							_END;
								for($j=0; $j<$numTypes; $j++){
									$permitType = $resultPermitType->fetch_array(MYSQLI_ASSOC);
									echo "<option value='$permitType[permit_type]'>$permitType[permit_type]</option>";
								}
							echo <<<_END
									</select></td>
								</tr>
								<tr>
									<td align='right'>Purchase Date:</td>
									<td>&emsp;<input type='text' name='purchase_date'></td>
								</tr>
								<tr>
									<td align='right'>Expiration Date:</td>
									<td>&emsp;<input type='text' name='expiration_date'></td>
								</tr>
								<tr>
									<td></td>
									<td><input type='submit' value='Add New Permit'></td>
								</tr>
							</table>
						</form>
						_END;
					}

					?>
					</table>
					</form>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="../js/scripts.js"></script>
    </body>
</html>
