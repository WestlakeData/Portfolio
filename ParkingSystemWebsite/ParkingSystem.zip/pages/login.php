<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="IS 6465 Final Project" />
        <meta name="author" content="Group5" />
        <title>Login-University of Utah Parking System</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Page content-->
                <div class="container-fluid">
					<img src='../assets/universityofutah-logo-1'>
                    <h1 class="mt-4">Parking System Management</h1>
                    <!-- Place Page Content HERE -->
						<br><br><br><br>
						<form id="login" method="post" action="login.php"> 
						<br><br><br><br><br>
							<label><b>Username</b><br>
							</label>    
							<input type="text" name="username" id="Uname" placeholder="Username"><br><br>    
							<label><b>Password</b><br>
							</label>
							<input type="Password" name="password" id="Pass" placeholder="Password"><br><br>    
							<input type="submit" name="log" id="log" value="Log In Here">       
							<br><br>
							<a href=Sign_up_page.php>
								<input type="button" name="NewUser" id="log" value="New user? Click here">
							</a>
						<br><br><br>
						</form>
						
						<?php

						require_once 'dbinfo.php';
						require_once 'user.php';
						
						$conn = new mysqli($hn, $un, $pw, $db);
						if($conn->connect_error) die($conn->connect_error);

						if (isset($_POST['username']) && isset($_POST['password'])) {
							
							//Get values from login screen
							$tmp_username = mysql_entities_fix_string($conn, $_POST['username']);
							$tmp_password = mysql_entities_fix_string($conn, $_POST['password']);
							
							//get password from DB w/ SQL
							$query = "SELECT hash FROM user WHERE user_id = '$tmp_username'";
							
							$result = $conn->query($query); 
							if(!$result) die($conn->error);
							
							$rows = $result->num_rows;
							$passwordFromDB="";
							for($j=0; $j<$rows; $j++)
							{
								$result->data_seek($j); 
								$row = $result->fetch_array(MYSQLI_ASSOC);
								$passwordFromDB = $row['hash'];
							
							}
							
							//Compare passwords
							if(password_verify($tmp_password,$passwordFromDB)) {
								$user = new User($tmp_username);
								session_start();
								$_SESSION['user'] = $user;
								header("Location: continue.php");
							}else{
								echo "login error<br>";
							}	
							
						}

						$conn->close();


						//sanitization functions
						function mysql_entities_fix_string($conn, $string){
							return htmlentities(mysql_fix_string($conn, $string));	
						}

						function mysql_fix_string($conn, $string){
							$string = stripslashes($string);
							return $conn->real_escape_string($string);
						}



						?>

	</body>	
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="../js/scripts.js"></script>
    </body>
</html>