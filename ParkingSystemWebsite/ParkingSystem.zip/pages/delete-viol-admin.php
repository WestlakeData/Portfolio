<?php
$page_roles = array('admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

$violationID = $_GET['id'];

if(isset($violationID)) {
	// DELETE Query
		$query = "DELETE FROM violation WHERE violation_id = '$violationID' ";
		$result = $conn->query($query); 
		if(!$result) die($conn->error);
	
	$conn->close();

}else{
	echo 'Error Deleting Violation<br>';
	echo '<a href="admin-viol.php">Return to Violation List Info</a>';
}

header("Location: admin-viol.php");
?>