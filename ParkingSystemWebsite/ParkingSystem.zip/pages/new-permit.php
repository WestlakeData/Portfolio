<?php
$page_roles = array('user', 'admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

if(isset($_POST['purchase'])) {
	if(isset($_POST['permitType']) &&
		isset($_POST['permitExp'])) {
			$permitType=get_post($conn, 'permitType');
			$permitExp=get_post($conn, 'permitExp');
			$permitPurchase=date("Y-m-d");
						
			// SELECT Query
			$query = "SELECT vehicle_id FROM vehicle WHERE driver_id = $driverID ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);
			
			$row = $result->fetch_array(MYSQLI_ASSOC);
			$vehicleID = $row['vehicle_id'];
			
			// INSERT Query
			$query = "INSERT INTO permit (permit_type, vehicle_id, driver_id, purchase_date, expiration_date) 
				VALUES ('$permitType', $vehicleID, $driverID, '$permitPurchase', '$permitExp') ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);	
	}
	
	$conn->close();

}else{
	echo 'Error Updating Vehicle Info<br>';
	echo '<a href="user-vehicle-info.php">Return to Vehicle Info</a>';
}

function get_post($conn, $var) {
		return $conn->real_escape_string($_POST[$var]);
}
header("Location: permit-thankyou.php");
?>