<?php
$page_roles = array('user', 'admin');
require_once 'user.php';
require_once 'checksession.php';
require_once 'dbinfo.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

if(isset($_POST['update'])) {
	if(isset($_POST['licenseNum']) &&
		isset($_POST['year']) &&
		isset($_POST['make']) &&
		isset($_POST['model']) &&
		isset($_POST['vehicle']) &&
		isset($_POST['color'])) {
			$vehicleID=get_post($conn, 'vehicle');
			$license=get_post($conn, 'licenseNum');
			$year=get_post($conn, 'year');
			$make=get_post($conn, 'make');
			$model=get_post($conn, 'model');
			$color=get_post($conn, 'color');
			
			// UPDATE Query
			$query = "UPDATE vehicle SET license_plate = '$license', vehicle_year = '$year', vehicle_make = '$make', vehicle_model = '$model', vehicle_color = '$color' WHERE vehicle_id = '$vehicleID' ";
			$result = $conn->query($query); 
			if(!$result) die($conn->error);	
	}
	
	$conn->close();

}else{
	echo 'Error Updating Vehicle Info<br>';
	echo '<a href="user-vehicle-info.php">Return to Vehicle Info</a>';
}

function get_post($conn, $var) {
		return $conn->real_escape_string($_POST[$var]);
}
header("Location: user-vehicle-info.php");
?>