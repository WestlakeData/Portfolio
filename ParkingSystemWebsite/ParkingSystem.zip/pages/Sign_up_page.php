<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="IS 6465 Final Project" />
        <meta name="author" content="Group5" />
        <title>Sign Up for Account</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="../css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Page content-->
                <div class="container-fluid">
					<img src='../assets/universityofutah-logo-1'>
                    <h1 class="mt-4">Parking System Management</h1>
                    <!-- Place Page Content HERE -->
                    <h2> New Registration</h2>
		<form method='post' action='login.php'>
			<pre>
				First Name: <input type='text' name='forename'>
				Last Name: <input type='text' name='surname'>
				Username: <input type='text' name='username'>
				Password: <input type='password' name='password'>
				<input type='submit' value='Sign Up'>
			</pre>
		</form>
	</body>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="../js/scripts.js"></script>
    </body>
</html>